from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType

#D1 EAST
D1BYTE_EAST = StructType([StructField("D1_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_East_Byte_Count", StringType(), True)])
D1COUNT_EAST = StructType([StructField("D1_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_East_Row_Count", StringType(), True)])
D1DDL_EAST = StructType([StructField("D1_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_East_Ddl_Count", StringType(), True)])
D1HASH_EAST = StructType([StructField("D1_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_East_Hash_Count", StringType(), True)])
D1UDF_EAST = StructType([StructField("D1_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_East_Udf_Count", StringType(), True)])

#D2A EAST
D2ABYTE_EAST = StructType([StructField("D2A_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_East_Byte_Count", StringType(), True)])
D2ACOUNT_EAST = StructType([StructField("D2A_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_East_Row_Count", StringType(), True)])
D2ADDL_EAST = StructType([StructField("D2A_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_East_Ddl_Count", StringType(), True)])
D2AHASH_EAST = StructType([StructField("D2A_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_East_Hash_Count", StringType(), True)])
D2AUDF_EAST = StructType([StructField("D2A_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_East_Udf_Count", StringType(), True)])


#D2B EAST
D2BBYTE_EAST = StructType([StructField("D2B_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_East_Byte_Count", StringType(), True)])
D2BCOUNT_EAST = StructType([StructField("D2B_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_East_Row_Count", StringType(), True)])
D2BDDL_EAST = StructType([StructField("D2B_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_East_Ddl_Count", StringType(), True)])
D2BHASH_EAST = StructType([StructField("D2B_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_East_Hash_Count", StringType(), True)])
D2BUDF_EAST = StructType([StructField("D2B_East_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_East_Udf_Count", StringType(), True)])

#D1 WEST
D1BYTE_WEST = StructType([StructField("D1_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_West_Byte_Count", StringType(), True)])
D1COUNT_WEST = StructType([StructField("D1_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_West_Row_Count", StringType(), True)])
D1DDL_WEST = StructType([StructField("D1_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_West_Ddl_Count", StringType(), True)])
D1HASH_WEST = StructType([StructField("D1_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_West_Hash_Count", StringType(), True)])
D1UDF_WEST = StructType([StructField("D1_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D1_West_Udf_Count", StringType(), True)])

#D2A WEST
D2ABYTE_WEST = StructType([StructField("D2A_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_West_Byte_Count", StringType(), True)])
D2ACOUNT_WEST = StructType([StructField("D2A_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_West_Row_Count", StringType(), True)])
D2ADDL_WEST = StructType([StructField("D2A_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_West_Ddl_Count", StringType(), True)])
D2AHASH_WEST = StructType([StructField("D2A_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_West_Hash_Count", StringType(), True)])
D2AUDF_WEST = StructType([StructField("D2A_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2A_West_Udf_Count", StringType(), True)])


#D2B WEST
D2BBYTE_WEST = StructType([StructField("D2B_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_West_Byte_Count", StringType(), True)])
D2BCOUNT_WEST = StructType([StructField("D2B_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_West_Row_Count", StringType(), True)])
D2BDDL_WEST = StructType([StructField("D2B_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_West_Ddl_Count", StringType(), True)])
D2BHASH_WEST = StructType([StructField("D2B_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_West_Hash_Count", StringType(), True)])
D2BUDF_WEST = StructType([StructField("D2B_West_Tbl_Nm", StringType(), True),StructField("Publn_Id", StringType(), True),StructField("D2B_West_Udf_Count", StringType(), True)])