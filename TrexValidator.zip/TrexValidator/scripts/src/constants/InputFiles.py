
    
#D1 EAST
D1BYTE_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D1/D1BYTE_EAST.txt'
D1COUNT_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D1/D1COUNT_EAST.txt'
D1DDL_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D1/D1DDL_EAST.txt'
D1HASH_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D1/D1HASH_EAST.txt'
D1UDF_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D1/D1UDF_EAST.txt'

#D2A EAST
D2ABYTE_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2A/D2ABYTE_EAST.txt'
D2ACOUNT_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2A/D2ACOUNT_EAST.txt'
D2ADDL_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2A/D2ADDL_EAST.txt'
D2AHASH_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2A/D2AHASH_EAST.txt'
D2AUDF_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2A/D2AUDF_EAST.txt'

#D2B EAST
D2BBYTE_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2B/D2BBYTE_EAST.txt'
D2BCOUNT_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2B/D2BCOUNT_EAST.txt'
D2BDDL_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2B/D2BDDL_EAST.txt'
D2BHASH_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2B/D2BHASH_EAST.txt'
D2BUDF_EAST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/EAST/D2B/D2BUDF_EAST.txt'


#D1 WEST
D1BYTE_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D1/D1BYTE_WEST.txt'
D1COUNT_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D1/D1COUNT_WEST.txt'
D1DDL_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D1/D1DDL_WEST.txt'
D1HASH_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D1/D1HASH_WEST.txt'
D1UDF_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D1/D1UDF_WEST.txt'

#D2A WEST
D2ABYTE_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2A/D2ABYTE_WEST.txt'
D2ACOUNT_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2A/D2ACOUNT_WEST.txt'
D2ADDL_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2A/D2ADDL_WEST.txt'
D2AHASH_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2A/D2AHASH_WEST.txt'
D2AUDF_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2A/D2AUDF_WEST.txt'

#D2B WEST
D2BBYTE_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2B/D2BBYTE_WEST.txt'
D2BCOUNT_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2B/D2BCOUNT_WEST.txt'
D2BDDL_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2B/D2BDDL_WEST.txt'
D2BHASH_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2B/D2BHASH_WEST.txt'
D2BUDF_WEST = 'file:///home/amitprasad/MyFolder/TrexValidator/input/WEST/D2B/D2BUDF_WEST.txt'
