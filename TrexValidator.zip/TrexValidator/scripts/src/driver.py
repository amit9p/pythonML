
import  constants.InputFiles as EastWestLoc
import  constants.ObjectRef as objRef
import  constants.Schema as schema
import  constants.sql as sql
import  constants.outputFiles as output 
import  sys
import  os


def main():

    
    #D1 EAST DFs
    D1BYTE_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1BYTE_EAST, header="false",inferSchema="true", schema = schema.D1BYTE_EAST)
    D1BYTE_EAST_DF.createOrReplaceTempView("D1BYTE_EAST")

    D1COUNT_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1COUNT_EAST, header="false",inferSchema="true", schema = schema.D1COUNT_EAST)
    D1COUNT_EAST_DF.createOrReplaceTempView("D1COUNT_EAST")
    
    D1DDL_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1DDL_EAST, header="false",inferSchema="true", schema = schema.D1DDL_EAST)
    D1DDL_EAST_DF.createOrReplaceTempView("D1DDL_EAST")
    
    D1HASH_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1HASH_EAST, header="false",inferSchema="true", schema = schema.D1HASH_EAST)
    D1HASH_EAST_DF.createOrReplaceTempView("D1HASH_EAST")

    D1UDF_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1UDF_EAST, header="false",inferSchema="true", schema = schema.D1UDF_EAST)
    D1UDF_EAST_DF.createOrReplaceTempView("D1UDF_EAST")
    
    
    
    #D2A EAST DFs
    D2ABYTE_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ABYTE_EAST, header="false",inferSchema="true", schema = schema.D2ABYTE_EAST)
    D2ABYTE_EAST_DF.createOrReplaceTempView("D2ABYTE_EAST")

    D2ACOUNT_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ACOUNT_EAST, header="false",inferSchema="true", schema = schema.D2ACOUNT_EAST)
    D2ACOUNT_EAST_DF.createOrReplaceTempView("D2ACOUNT_EAST")

    D2ADDL_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ADDL_EAST, header="false",inferSchema="true", schema = schema.D2ADDL_EAST)
    D2ADDL_EAST_DF.createOrReplaceTempView("D2ADDL_EAST")

    D2AHASH_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2AHASH_EAST, header="false",inferSchema="true", schema = schema.D2AHASH_EAST)
    D2AHASH_EAST_DF.createOrReplaceTempView("D2AHASH_EAST")

    D2AUDF_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2AUDF_EAST, header="false",inferSchema="true", schema = schema.D2AUDF_EAST)
    D2AUDF_EAST_DF.createOrReplaceTempView("D2AUDF_EAST")

    


    #D2B EAST DFs
    D2BBYTE_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BBYTE_EAST, header="false",inferSchema="true", schema = schema.D2BBYTE_EAST)
    D2BBYTE_EAST_DF.createOrReplaceTempView("D2BBYTE_EAST")

    D2BCOUNT_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BCOUNT_EAST, header="false",inferSchema="true", schema = schema.D2BCOUNT_EAST)
    D2BCOUNT_EAST_DF.createOrReplaceTempView("D2BCOUNT_EAST")

    D2BDDL_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BDDL_EAST, header="false",inferSchema="true", schema = schema.D2BDDL_EAST)
    D2BDDL_EAST_DF.createOrReplaceTempView("D2BDDL_EAST")

    D2BHASH_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BHASH_EAST, header="false",inferSchema="true", schema = schema.D2BHASH_EAST)
    D2BHASH_EAST_DF.createOrReplaceTempView("D2BHASH_EAST")

    D2BUDF_EAST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BUDF_EAST, header="false",inferSchema="true", schema = schema.D2BUDF_EAST)
    D2BUDF_EAST_DF.createOrReplaceTempView("D2BUDF_EAST")


    

    #D1 WEST DFs
    D1BYTE_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1BYTE_WEST, header="false",inferSchema="true", schema = schema.D1BYTE_WEST)
    D1BYTE_WEST_DF.createOrReplaceTempView("D1BYTE_WEST")

    D1COUNT_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1COUNT_WEST, header="false",inferSchema="true", schema = schema.D1COUNT_WEST)
    D1COUNT_WEST_DF.createOrReplaceTempView("D1COUNT_WEST")

    D1DDL_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1DDL_WEST, header="false",inferSchema="true", schema = schema.D1DDL_WEST)
    D1DDL_WEST_DF.createOrReplaceTempView("D1DDL_WEST")

    D1HASH_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1HASH_WEST, header="false",inferSchema="true", schema = schema.D1HASH_WEST)
    D1HASH_WEST_DF.createOrReplaceTempView("D1HASH_WEST")

    D1UDF_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D1UDF_WEST, header="false",inferSchema="true", schema = schema.D1UDF_WEST)
    D1UDF_WEST_DF.createOrReplaceTempView("D1UDF_WEST")

    


    #D2A WEST DFs
    D2ABYTE_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ABYTE_WEST, header="false",inferSchema="true", schema = schema.D2ABYTE_WEST)
    D2ABYTE_WEST_DF.createOrReplaceTempView("D2ABYTE_WEST")

    D2ACOUNT_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ACOUNT_WEST, header="false",inferSchema="true", schema = schema.D2ACOUNT_WEST)
    D2ACOUNT_WEST_DF.createOrReplaceTempView("D2ACOUNT_WEST")

    D2ADDL_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2ADDL_WEST, header="false",inferSchema="true", schema = schema.D2ADDL_WEST)
    D2ADDL_WEST_DF.createOrReplaceTempView("D2ADDL_WEST")

    D2AHASH_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2AHASH_WEST, header="false",inferSchema="true", schema = schema.D2AHASH_WEST)
    D2AHASH_WEST_DF.createOrReplaceTempView("D2AHASH_WEST")

    D2AUDF_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2AUDF_WEST, header="false",inferSchema="true", schema = schema.D2AUDF_WEST)
    D2AUDF_WEST_DF.createOrReplaceTempView("D2AUDF_WEST")




    #D2B WEST DFs
    D2BBYTE_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BBYTE_WEST, header="false",inferSchema="true", schema = schema.D2BBYTE_WEST)
    D2BBYTE_WEST_DF.createOrReplaceTempView("D2BBYTE_WEST")

    D2BCOUNT_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BCOUNT_WEST, header="false",inferSchema="true", schema = schema.D2BCOUNT_WEST)
    D2BCOUNT_WEST_DF.createOrReplaceTempView("D2BCOUNT_WEST")

    D2BDDL_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BDDL_WEST, header="false",inferSchema="true", schema = schema.D2BDDL_WEST)
    D2BDDL_WEST_DF.createOrReplaceTempView("D2BDDL_WEST")

    D2BHASH_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BHASH_WEST, header="false",inferSchema="true", schema = schema.D2BHASH_WEST)
    D2BHASH_WEST_DF.createOrReplaceTempView("D2BHASH_WEST")

    D2BUDF_WEST_DF = objRef.sparkSession.read.csv(EastWestLoc.D2BUDF_WEST, header="false",inferSchema="true", schema = schema.D2BUDF_WEST)
    D2BUDF_WEST_DF.createOrReplaceTempView("D2BUDF_WEST")


    # Generating D1 Matching Reports For EAST And WEST
    d1_byteCount = objRef.sparkSession.sql(sql.d1_byteCount_sql)
    d1_byteCount.repartition(1).write.csv(path=output.D1+'/d1_byteCount', mode="append", header="true")

    d1_rowCount = objRef.sparkSession.sql(sql.d1_rowCount_sql)
    d1_rowCount.repartition(1).write.csv(path=output.D1+'/d1_rowCount', mode="append", header="true")

    d1_ddl = objRef.sparkSession.sql(sql.d1_ddl_sql)
    d1_ddl.repartition(1).write.csv(path=output.D1+'/d1_ddl', mode="append", header="true")

    d1_hashCount = objRef.sparkSession.sql(sql.d1_hashCount_sql)
    d1_hashCount.repartition(1).write.csv(path=output.D1+'/d1_hashCount', mode="append", header="true")

    d1_udfCount = objRef.sparkSession.sql(sql.d1_udfCount_sql)
    d1_udfCount.repartition(1).write.csv(path=output.D1+'/d1_udfCount', mode="append", header="true")

    #Generating D2A Matching Reports For EAST And WEST

    d2a_byteCount = objRef.sparkSession.sql(sql.d2a_byteCount_sql)
    d2a_byteCount.repartition(1).write.csv(path=output.D2A+'/d2a_byteCount', mode="append", header="true")

    d2a_rowCount = objRef.sparkSession.sql(sql.d2a_rowCount_sql)
    d2a_rowCount.repartition(1).write.csv(path=output.D2A+'/d2a_rowCount', mode="append", header="true")

    d2a_ddl = objRef.sparkSession.sql(sql.d2a_ddl_sql)
    d2a_ddl.repartition(1).write.csv(path=output.D2A+'/d2a_ddl', mode="append", header="true")

    d2a_hashCount = objRef.sparkSession.sql(sql.d2a_hashCount_sql)
    d2a_hashCount.repartition(1).write.csv(path=output.D2A+'/d2a_hashCount', mode="append", header="true")

    d2a_udfCount = objRef.sparkSession.sql(sql.d2a_udfCount_sql)
    d2a_udfCount.repartition(1).write.csv(path=output.D2A+'/d2a_udfCount', mode="append", header="true")


    #Generating D2B Matching Reports For EAST And WEST

    d2b_byteCount = objRef.sparkSession.sql(sql.d2b_byteCount_sql)
    d2b_byteCount.repartition(1).write.csv(path=output.D2B+'/d2b_byteCount', mode="append", header="true")

    d2b_rowCount = objRef.sparkSession.sql(sql.d2b_rowCount_sql)
    d2b_rowCount.repartition(1).write.csv(path=output.D2B+'/d2b_rowCount', mode="append", header="true")

    d2b_ddl = objRef.sparkSession.sql(sql.d2b_ddl_sql)
    d2b_ddl.repartition(1).write.csv(path=output.D2B+'/d2b_ddl', mode="append", header="true")

    d2b_hashCount = objRef.sparkSession.sql(sql.d2b_hashCount_sql)
    d2b_hashCount.repartition(1).write.csv(path=output.D2B+'/d2b_hashCount', mode="append", header="true")

    d2b_udfCount = objRef.sparkSession.sql(sql.d2b_udfCount_sql)
    d2b_udfCount.repartition(1).write.csv(path=output.D2B+'/d2b_udfCount', mode="append", header="true")


    #######################################################################################################

    # Generating D1 Non Matching Reports For EAST And WEST
    d1_byteCount_ = objRef.sparkSession.sql(sql.d1_byteCount_sql_)
    d1_byteCount_.repartition(1).write.csv(path=output.D1_+'/d1_byteCount', mode="append", header="true")

    d1_rowCount_ = objRef.sparkSession.sql(sql.d1_rowCount_sql_)
    d1_rowCount_.repartition(1).write.csv(path=output.D1_+'/d1_rowCount', mode="append", header="true")

    d1_ddl_ = objRef.sparkSession.sql(sql.d1_ddl_sql_)
    d1_ddl_.repartition(1).write.csv(path=output.D1_+'/d1_ddl', mode="append", header="true")

    d1_hashCount_ = objRef.sparkSession.sql(sql.d1_hashCount_sql_)
    d1_hashCount_.repartition(1).write.csv(path=output.D1_+'/d1_hashCount', mode="append", header="true")

    d1_udfCount_ = objRef.sparkSession.sql(sql.d1_udfCount_sql_)
    d1_udfCount_.repartition(1).write.csv(path=output.D1_+'/d1_udfCount', mode="append", header="true")

    #Generating D2A Non Matching Reports For EAST And WEST

    d2a_byteCount_ = objRef.sparkSession.sql(sql.d2a_byteCount_sql_)
    d2a_byteCount_.repartition(1).write.csv(path=output.D2A_+'/d2a_byteCount', mode="append", header="true")

    d2a_rowCount_ = objRef.sparkSession.sql(sql.d2a_rowCount_sql_)
    d2a_rowCount_.repartition(1).write.csv(path=output.D2A_+'/d2a_rowCount', mode="append", header="true")

    d2a_ddl_ = objRef.sparkSession.sql(sql.d2a_ddl_sql_)
    d2a_ddl_.repartition(1).write.csv(path=output.D2A_+'/d2a_ddl', mode="append", header="true")

    d2a_hashCount_ = objRef.sparkSession.sql(sql.d2a_hashCount_sql_)
    d2a_hashCount_.repartition(1).write.csv(path=output.D2A_+'/d2a_hashCount', mode="append", header="true")

    d2a_udfCount_ = objRef.sparkSession.sql(sql.d2a_udfCount_sql_)
    d2a_udfCount_.repartition(1).write.csv(path=output.D2A_+'/d2a_udfCount', mode="append", header="true")


    #Generating D2B Non Matching Reports For EAST And WEST

    d2b_byteCount_ = objRef.sparkSession.sql(sql.d2b_byteCount_sql_)
    d2b_byteCount_.repartition(1).write.csv(path=output.D2B_+'/d2b_byteCount', mode="append", header="true")

    d2b_rowCount_ = objRef.sparkSession.sql(sql.d2b_rowCount_sql_)
    d2b_rowCount_.repartition(1).write.csv(path=output.D2B_+'/d2b_rowCount', mode="append", header="true")

    d2b_ddl_ = objRef.sparkSession.sql(sql.d2b_ddl_sql_)
    d2b_ddl_.repartition(1).write.csv(path=output.D2B_+'/d2b_ddl', mode="append", header="true")

    d2b_hashCount_ = objRef.sparkSession.sql(sql.d2b_hashCount_sql_)
    d2b_hashCount_.repartition(1).write.csv(path=output.D2B_+'/d2b_hashCount', mode="append", header="true")

    d2b_udfCount_ = objRef.sparkSession.sql(sql.d2b_udfCount_sql_)
    d2b_udfCount_.repartition(1).write.csv(path=output.D2B_+'/d2b_udfCount', mode="append", header="true")

    
    objRef.sparkSession.stop()
    

    

    
    

main()